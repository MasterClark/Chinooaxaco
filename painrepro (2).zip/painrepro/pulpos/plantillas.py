from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

_start = """ ¡𝙃𝙊𝙇𝘼 𝘼 𝙏𝙊𝘿𝙊𝙎 𝘽𝙄𝙀𝙉𝙑𝙀𝙉𝙄𝘿𝙊!
"""
_cmd = """<b>¡𝙃𝙤𝙡𝙖, 𝙥𝙖𝙧𝙖 𝙖𝙥𝙧𝙚𝙣𝙙𝙚𝙧 𝙨𝙤𝙗𝙧𝙚 𝙢𝙞𝙨 𝙘𝙤𝙢𝙖𝙣𝙙𝙤𝙨, 𝙥𝙧𝙚𝙨𝙞𝙤𝙣𝙚 𝙘𝙪𝙖𝙡𝙦𝙪𝙞𝙚𝙧𝙖 𝙙𝙚 𝙡𝙤𝙨 𝙗𝙤𝙩𝙤𝙣𝙚𝙨!
</b>
"""

dbre = InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton("𝙊𝙒𝙉𝙀𝙍", url="t.me/THE_ORGULLOT"),
                
            ]
            
        ]

    )
    
 
mainstart = InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "Gateways",
                            callback_data="gater"
                        ),
                        InlineKeyboardButton(
                            "Tools",
                            callback_data="tools"
                        ),
                ],
                [
                        InlineKeyboardButton(
                            "Price",
                            callback_data="buy"
                        ),
                        InlineKeyboardButton(
                            "Exit !",
                            callback_data="exit"
                ),
                    ],
                ]
            )
buycmd = reply_markup=InlineKeyboardMarkup(
        [
            [
        
                InlineKeyboardButton("𝙊𝙒𝙉𝙀𝙍", url="t.me/THE_ORGULLOT"),

InlineKeyboardButton("𝗛𝗼𝗺𝗲",callback_data="home"),
                
            ]
            
        ]

    )
    
_cmdbotons = InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            "Mass",
                            callback_data="mass"
                        ),
                        InlineKeyboardButton(
                            "Charged",
                            callback_data="char"
                        ),
                ],
                [
                        InlineKeyboardButton(
                            "Braintree",
                            callback_data="ccn"
                        ),
                        InlineKeyboardButton(
                            "Auth",
                            callback_data="auth"
                        ),
                ],
                [
                        InlineKeyboardButton(
                            "Home",
                            callback_data="home"
                ),
                    ],
                ]
            )
    
_Call_Regis = """<b>Querido Usuari@ Registro Correcto Puedes poner ya /cmds para ver los gates y tools</b>"""

_Call_Tools = """<b>

𝗧𝗼𝗼𝗹𝘀 🔥
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┣➣𝗕𝗶𝗻 ⇝ 𝗙𝗥𝗘𝗘
┣➣𝗨𝘀𝗮𝗿 /bin 456789
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┣➣ 𝗚𝗲𝗻 𝗰𝗰𝘀 𝗙𝗥𝗘𝗘
┣➣ 𝗨𝘀𝗮𝗿 /gen 53324821503xxxx|07|2023|rnd
┣
┣➣ 𝗥𝗮𝗻𝗱 - 𝗙𝗥𝗘𝗘
┣➣ 𝗨𝘀𝗮𝗿 /rnd 𝗨𝗦𝗔 𝗼𝗿 /pais
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┣➣ 𝗦𝗽𝗼𝘁𝗶𝗳𝘆 - 𝗙𝗥𝗘𝗘
┣➣ 𝗨𝘀𝗮𝗿 /Spotify 
┣
┣➣ 𝗖𝗖 𝗿𝗮𝗻𝗱𝗼𝗺 - 𝗙𝗥𝗘𝗘
┣
┣➣ 𝗭𝗶𝗽 𝗰𝗼𝗱𝗲 𝗣𝗼𝘀𝘁𝗮𝗹 - 𝗙𝗥𝗘𝗘
┣➣ 𝗨𝘀𝗮𝗿 /zip 10080
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━<b>"""

_Call_Auth = """<b>

┏━━━━━━━━━━━━━━━━━
┣━ 𝗚𝗔𝗧𝗘𝗦 𝗔𝗨𝗧𝗛🔥 ━━━━
┣━━━━━━━━━━━━━━━━━
┣ Pain | Access ✅
┣ ɢᴀᴛᴇᴡᴀʏ  [Auth]
┣ ꜰᴏʀᴍᴀᴛ  /cb card|m|y|cvv
┣━━━━━━━━━━━━━━━━━
┣ pain | off ❌ 
┣ ɢᴀᴛᴇᴡᴀʏ  [Auth]
┣ ꜰᴏʀᴍᴀᴛ  /sb card|m|y|cvv
┗━━━━━━━━━━━━━━━━━
</b>"""

_Call_Charged = """<b>

┏━━━━━━━━━━━━━━━━━
┣━ 𝗚𝗔𝗧𝗘𝗦 𝗖𝗛𝗔𝗥𝗚𝗘𝗗🔥 ━━━━
┣━━━━━━━━━━━━━━━━━
┣ Pain | Access ✅
┣ ɢᴀᴛᴇᴡᴀʏ  [charged]
┣ ꜰᴏʀᴍᴀᴛ  /fr card|m|y|cvv
┣━━━━━━━━━━━━━━━━━
┣ pain | off ❌
┣ ɢᴀᴛᴇᴡᴀʏ  [charged]
┣ ꜰᴏʀᴍᴀᴛ  /yr card|m|y|cvv
┣━━━━━━━━━━━━━━━━━
┣ Pain | Access ✅
┣ ɢᴀᴛᴇᴡᴀʏ  [Auth]
┣ ꜰᴏʀᴍᴀᴛ  /sen card|m|y|cvv
┗━━━━━━━━━━━━━━━━━
</b>"""

_Call_mass = """<b>

𝙂𝙖𝙩𝙚𝙨 𝙈𝙖𝙨𝙨 𝘼𝙪𝙩𝙝 𝙮 𝘾𝙝𝙖𝙧𝙜𝙚𝙙
━━━━━━━━━━━━━━━━━━━━━━
𝙊𝙁𝙁
 ━━━━━━━━━━━━━━━━━━━━━━
</𝙗>"""

_𝘾𝙖𝙡𝙡_𝘽𝙧𝙖𝙞𝙣𝙩𝙧𝙚𝙚 = """<𝙗>

𝙂𝙖𝙩𝙚𝙨 𝘽𝙧𝙖𝙞𝙣𝙩𝙧𝙚𝙚
━━━━━━━━━━━━━━━━━━━━━━
 𝙊𝙁𝙁
━━━━━━━━━━━━━━━━━━━━━━
</b>"""

_Call_Gateways_buttons = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(
                    "Back ",
                    callback_data="gater"
                ),
                InlineKeyboardButton(
                    "Close",
                    callback_data="exit"
                ),
        ]
        ]
    )
