from configss._def_main_ import *


@Client.on_message(filters.command(["start"], ["/", "."]))
async def start(client,m):
    await m.reply(text=f"""
<b>𝘽𝙞𝙚𝙣𝙫𝙚𝙣𝙞𝙙𝙤 𝙖  𝗣𝗔𝗜𝗡 𝗖𝗛𝗞 [𝗣𝗕 𝗖𝗛𝗞]🔥 𝙈𝙞 𝙘𝙧𝙚𝙖𝙙𝙤𝙧 𝙚𝙨 @THE_ORGULLOT

𝙍𝙚𝙫𝙞𝙨𝙖 𝙣𝙪𝙚𝙨𝙩𝙧𝙤𝙨 𝙘𝙤𝙢𝙖𝙣𝙙𝙤𝙨 𝙥𝙖𝙧𝙖 𝙦𝙪𝙚 𝙡𝙤𝙨 𝙪𝙨𝙚𝙨 𝙘𝙤𝙢𝙤 𝙢á𝙨 𝙩𝙚 𝙜𝙪𝙨𝙩𝙚! </b>
     """,
    reply_markup=InlineKeyboardMarkup(
        [
            [
        
                InlineKeyboardButton("✵ 𝑶𝒘𝒏𝒆𝒓 1 ", url="t.me/THE_ORGULLOT"),
                InlineKeyboardButton("✵ 𝑶𝒘𝒏𝒆𝒓 2 ", url="t.me/Swnfloxs"),
        ],
        [        
                InlineKeyboardButton("𝙍𝙀𝙁𝙀𝙍𝙀𝙉𝘾𝙄𝘼", url="https://t.me/referencias_pain_chk_bot"),
                
            ]
            
        ]

    )
    
 )

