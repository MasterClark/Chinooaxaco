from configss._def_main_ import *
from pulpos.plantillas import mainstart, _cmd

@Client.on_message(filters.command(["cmds"], ["/", "."]))
async def cmds(client, message):
    with open(file='plugins/usuarios/users.txt',mode='r+',encoding='utf-8') as archivo:
        x = archivo.readlines()
        if str(message.from_user.id) + '\n' in x:
            await message.reply(_cmd, reply_markup= mainstart)
        else:
            return await message.reply(f'<b>[☃] Registrate sino eres Gey <code>/register</code></b>')
    