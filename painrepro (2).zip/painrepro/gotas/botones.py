from pyrogram.types import *

mainstart = InlineKeyboardMarkup([[InlineKeyboardButton("𝗚𝗮𝘁𝗲𝗿𝘄𝗮𝘆𝘀 「︎⚡️」︎",callback_data="gater"),InlineKeyboardButton("𝗕𝘂𝘆 ",callback_data="buy")],[InlineKeyboardButton("❗️𝗘𝘅𝗶𝘁❗️ ",callback_data="exit")]])

atras = InlineKeyboardMarkup([[InlineKeyboardButton("𝗛𝗼𝗺𝗲 🌨",callback_data="home"),InlineKeyboardButton("❗️𝗘𝘅𝗶𝘁❗️",callback_data="exit")]])

homedb = InlineKeyboardMarkup([[InlineKeyboardButton("𝗛𝗼𝗺𝗲 🌨",callback_data="home")]])

regene = InlineKeyboardMarkup([[InlineKeyboardButton("Regenerar 🌨",callback_data="regen")]])