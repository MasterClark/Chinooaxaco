buy = '''<b>

┏━━━━━━━━━━━━━━
┣ 				𝙥𝙧𝙚𝙘𝙞𝙤𝙨
┗━━━━━━━━━━━━━━
 ╌ ╌ ╌ ╌ ╌ ╌ ╌ ╌ ╌ ╌ ╌ ╌
𝙇𝙤 𝙨𝙞𝙚𝙣𝙩𝙤, 𝙣𝙤 𝙝𝙖𝙮 𝙥𝙧𝙚𝙘𝙞𝙤𝙨. 𝙀𝙨𝙩𝙚 𝙗𝙤𝙩 𝙨𝙚 𝙚𝙣𝙘𝙪𝙚𝙣𝙩𝙧𝙖 𝙖𝙘𝙩𝙪𝙖𝙡𝙢𝙚𝙣𝙩𝙚 𝙚𝙣 𝙙𝙚𝙨𝙖𝙧𝙧𝙤𝙡𝙡𝙤. 𝙀𝙨𝙩á 𝙙𝙞𝙨𝙥𝙤𝙣𝙞𝙗𝙡𝙚 𝙚𝙣 𝙜𝙧𝙪𝙥𝙤𝙨 𝙮 𝙪𝙨𝙪𝙖𝙧𝙞𝙤𝙨 𝙥𝙧𝙚𝙢𝙞𝙪𝙢.

𝘾𝙊𝙉𝙏𝘼𝘾𝙏𝘼𝙏𝙀 𝘾𝙊𝙉 𝙇𝙊𝙎 𝙊𝙒𝙉𝙀𝙍

➨ 𝙊𝙒𝙉𝙀𝙍 : @THE_ORGULLOT
➨ 𝙊𝙒𝙉𝙀𝙍 2 : @Swnfloxs
➨ 𝙊𝙒𝙉𝙀𝙍 3: @madara_repro
➨ 𝗔𝗱𝗺𝗶𝗻: @lsmi09

➣the deal will be made by spam 
 ╌ ╌ ╌ ╌ ╌ ╌ ╌ ╌ ╌ ╌ ╌ ╌
</b>'''
perfil = """<b>[ツ] ︎𝐈𝐧𝐟𝐨𝐫𝐦𝐚𝐜𝐢𝐨𝐧 𝐃𝐞𝐥 𝐔𝐬𝐮𝐚𝐫𝐢𝐨 「︎🪪
    
❀ {name}

❀ ALias : @{username}
❀ Id : <code>{id}</code>
❀ Estado : {rank}
❀ Key : none

チ 𝙏𝙞𝙢𝙚 : <code>0.8(sg)</code>
━━━━━━━━━
ツ Owner -» @THE_ORGULLOT
━━━━━━━━━
</b>"""

gatertt = '''<b>

🔥 𝙀𝙎𝙏𝙊𝙎 𝙎𝙊𝙉 𝙈𝙄𝙎 𝙂𝘼𝙏𝙀𝙎 🔥
┏━━━━━━━━━━━━━━━━━
┣𝙂𝘼𝙏𝙀𝙎 𝙊𝙉 ➨4
┣𝙂𝘼𝙏𝙀𝙎 𝙊𝙁𝙁 ➨2
┣━━━━━━━━━━━━━━━━━━
┣𝙂𝘼𝙏𝙀𝙎 𝘼𝙐𝙏𝙃 ➨ 3
┣𝙂𝘼𝙏𝙀𝙎 𝘾𝙃𝘼𝙍𝙂𝙀𝘿 ➨3
┣━━━━━━━━━━━━━━━━━
┣𝘾𝙃𝙆 𝘽𝙔: @THE_ORGULLOT
┗━━━━━━━━━━━━━━━━━</b>'''

bin = '''<b>[•] <a href="tg://user?id=InefableRexBot">Bin info 「︎📍」︎</a>

メ bin  ⇾ <code>{binif}</code>
メ brand  ⇾ <code>{brand}</code>
メ country  ⇾ <code>{country} | {country_name} | {country_flag}</code>
メ bank  ⇾ <code>{bank}</code>
メ level  ⇾ <code>{level}</code>
メ tipo  ⇾ <code>{type}</code>
-
チ 𝑪𝒉𝒌 𝑩𝒚 ➵ {name}
チ 𝙏𝙞𝙢𝙚 -» <code>0.2</code>
━━━━━━━━━
ツ Owner -» @THE_ORGULLOT
━━━━━━━━━

</b>'''


sk = '''<b>[•] <a href="tg://user?id=InefableRexBot">Sk Key 「︎📍」︎</a>

チ Response  ⇾ <code>{res}</code>
チ Message  ⇾ <code>{message}</code>
-
チ 𝑪𝒉𝒌 𝑩𝒚 ➵ {name}
チ 𝙏𝙞𝙢𝙚 -» <code>0.2</code>
━━━━━━━━━
ツ Owner -» @THE_ORGULLOT
━━━━━━━━━</b>'''



nrd = '''<b>[•] <a href="tg://user?id=InefableRexBot">Fake Generador 「︎📍」︎</a>

ツ genero ⇾ <code>{genero}</code>
ツ Name ⇾ <code>{mr} {first} {last}</code>      
ツ Correo ⇾ <code>{mail}</code>      
ツ Ciudad ⇾ <code>{ciudad}</code>      
ツ Estado ⇾ <code>{state}</code>       
ツ Pais ⇾ <code>{country}</code>      
ツ Codigo Postal⇾ <code>{zip}</code>
-
チ 𝑪𝒉𝒌 𝑩𝒚 ➵  {name}
チ 𝙏𝙞𝙢𝙚 -» <code>0.2</code>
━━━━━━━━━
ツ Owner -» @THE_ORGULLOT
━━━━━━━━━</b>'''



ip = '''<b>[•] <a href="tg://user?id=InefableRexBot">Ip checkin 「︎📍」︎</a>

朱 ip ⇾ <code>{ips}</code>
朱 Status ⇾ <code>True ✅</code>
朱 country  ⇾ <code>{country} | {country_code} | {emoji}</code>      
朱 Cordenadas ⇾ <code>{lat} | {lon}</code>      
朱 Ciudad ⇾ <code>{city}</code>           
朱 Dominio  ⇾ <code>{domi}</code>      
朱 Codigo Postal⇾ <code>{zip}</code>
-
チ 𝑪𝒉𝒌 𝑩𝒚 ➵ {name}
チ 𝙏𝙞𝙢𝙚 -» <code>0.2</code>
━━━━━━━━━
ツ Owner -» @THE_ORGULLOT
━━━━━━━━━</b>'''


info = '''<b>[•] <a href="tg://user?id=InefableRexBot">𝐈𝐧𝐟𝐨𝐫𝐦𝐚𝐜𝐢𝐨𝐧 𝐃𝐞𝐥 𝐔𝐬𝐮𝐚𝐫𝐢𝐨 「︎🪪」︎</a>

❀ Name ⇾ <code>{name}</code>
❀ id ⇾ <code>{id} | {idchat}</code>      
❀ alias ⇾ <code>@{alias}</code>      
❀ Estado ⇾ <code>Free</code> 
-
チ 𝙏𝙞𝙢𝙚 -» <code>0.2</code>
━━━━━━━━━
ツ Owner -» @THE_ORGULLOT
━━━━━━━━━</b>'''

zip = '''<b>[•] <a href="tg://user?id=InefableRexBot">Codigo Postal 「︎📍」︎</a>

零 Zip ⇾ <code>{cap}</code>
零 Status ⇾ <code>True ✅</code>
零 country  ⇾ <code>{pais}</code>          
零 Ciudad ⇾ <code>{ciudad}</code>           
零 Estado  ⇾ <code>{estado}</code>     
-
チ 𝑪𝒉𝒌 𝑩𝒚 ➵ {name}
チ 𝙏𝙞𝙢𝙚 -» <code>0.2</code>
━━━━━━━━━
ツ Owner -» @THE_ORGULLOT
━━━━━━━━━</b>'''

gen = '''<b>[•] <a href="tg://user?id=InefableRexBot">𝐆𝐞𝐧𝐞𝐫𝐚𝐝𝐨𝐫 𝐝𝐞 𝐓𝐚𝐫𝐣𝐞𝐭𝐚𝐬「⚕️」︎</a>

✵ bin  ⎇ <code>{binif}</code>
✵ Monton  ⎇ <code>10</code>
✵ country  ⎇ <code>{country} | {country_name} | {country_flag}</code>
━
<code>{cc1}</code>
<code>{cc2}</code>  
<code>{cc3}</code>
<code>{cc4}</code> 
<code>{cc5}</code>
<code>{cc6}</code>
<code>{cc7}</code>
<code>{cc8}</code>
<code>{cc9}</code>
<code>{cc10}</code>
-
チ 𝙏𝙞𝙢𝙚 -» <code>0.2</code>
━━━━━━━━━
ツ Owner -» @THE_ORGULLOT
━━━━━━━━━
</b>'''

chres = '''<b>[•]  <a href="tg://user?id=InefableRexBot">Stripe charged 「︎⚡️」︎</a>

朱 <code>{ccs}</code>
朱 Status ⇾ {stat}
朱 Response ⇾ {respo}
朱 Message ⇾ <code>{message}</code>
朱 Code ⇾ <code>{code}</code>
-
朱 take ⇾ 2.9 s
朱 Proxy ⇾ live ✅
朱 chk ⇾ {name}
━━━━━━━━━
ツ Owner -» @THE_ORGULLOT
━━━━━━━━━</b>'''

ccn = 'Live CCN ✅'
livecc = 'Cc live'
fund = 'insufficient funds.'
aproved = 'Aproved ✅'
char = 'Cc live charge $3.99'
sst = 'success:True'
deadcc = 'Cc muerta ❌'
inco = 'Incorrecta respuesta'
cad = 'Cc Dead'
ereq = 'Error req'